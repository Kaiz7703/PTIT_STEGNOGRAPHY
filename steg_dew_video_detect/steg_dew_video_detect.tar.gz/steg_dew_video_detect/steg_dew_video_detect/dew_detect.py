import cv2
import numpy as np
from scipy.fft import dct
import argparse
import os
import matplotlib.pyplot as plt

class DEWDetector:
    def __init__(self, block_size=8, n=2):
        self.block_size = block_size
        self.n = n

    def calculate_energy(self, dct_block, start_idx, end_idx):
        """Calculating energy"""
        return np.sum(np.square(dct_block[start_idx:end_idx]))

    def analyze_block(self, dct_block):
        """Analyzing DCT"""
        EA = self.calculate_energy(dct_block, 0, 35)
        EB = self.calculate_energy(dct_block, 35, 64)

        energy_ratio = abs(EA - EB) / (EA + EB) if (EA + EB) > 0 else 0
        zero_coeffs = np.sum(np.abs(dct_block) < 0.01)  
        
        return energy_ratio, zero_coeffs

    def detect_steganography(self, input_video, save_plot=False):
        """Detecting .."""
        print("Analyzing video...", end=' ')
        cap = cv2.VideoCapture(input_video)
        if not cap.isOpened():
            raise Exception("Can not open file")

        energy_ratios = []
        zero_counts = []
        frame_count = 0
        
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break

            if frame_count % 12 == 0:
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

                for i in range(0, gray.shape[0] - self.block_size + 1, self.block_size * self.n):
                    for j in range(0, gray.shape[1] - self.block_size + 1, self.block_size * self.n):
                        block = gray[i:i+self.block_size, j:j+self.block_size]
                        dct_block = dct(dct(block.T, norm='ortho').T, norm='ortho').flatten()
                        
                        ratio, zeros = self.analyze_block(dct_block)
                        energy_ratios.append(ratio)
                        zero_counts.append(zeros)

            frame_count += 1

        cap.release()

        ratios_mean = np.mean(energy_ratios)
        ratios_std = np.std(energy_ratios)
        zeros_mean = np.mean(zero_counts)
 
        if save_plot:
            plt.figure(figsize=(10, 5))
            plt.hist(energy_ratios, bins=50)
            plt.title('DCT Energy ratio')
            plt.xlabel('Energy Ratio')
            plt.ylabel('Frequency')
            plt.savefig(input_video.rsplit('.', 1)[0] + '_analysis.png')
            plt.close()

        suspicious_score = 0

        if ratios_std > 0.010:
            suspicious_score += 1.0
        if zeros_mean < 50:
            suspicious_score += 0.5
        if abs(ratios_mean - 1.0) > 0.002:
            suspicious_score += 0.5

        print("OK!")
        print(f"\nResult:")
        print(f"- Ratio of energy: {ratios_mean:.3f}")
        print(f"- Ratio of std: {ratios_std:.3f}")
        print(f"- Number of average 0: {zeros_mean:.1f}")
        print(f"- Suspicious: {suspicious_score}/3")

        return suspicious_score >= 1.5

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Phát hiện giấu tin trong video MPEG')
    parser.add_argument('video_path', help='Đường dẫn đến video cần phân tích')
    parser.add_argument('--plot', action='store_true', help='Vẽ đồ thị phân tích')
    args = parser.parse_args()

    try:
        print("\n=== DEW DETECTION PROGRAM ===\n")
        detector = DEWDetector()
        is_suspicious = detector.detect_steganography(args.video_path, args.plot)
        
        print("\nResult:")
        if is_suspicious:
            print("Video has stegnography!")
        else:
            print("Nothing detected.")

    except Exception as e:
        print(f"\nError: {str(e)}")
