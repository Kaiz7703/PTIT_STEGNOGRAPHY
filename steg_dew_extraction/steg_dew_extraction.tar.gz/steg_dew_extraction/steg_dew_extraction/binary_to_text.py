import os

# Đường dẫn đến file nhị phân cần chuyển đổi
INPUT_BINARY_PATH = "../sample_video_embedded_extracted_binary.txt"  #PATH

def convert_to_text(input_path=INPUT_BINARY_PATH):
    """Chuyển đổi file nhị phân thành văn bản"""
    if not os.path.exists(input_path):
        raise FileNotFoundError(f"Không tìm thấy file: {input_path}")
        
    # Đọc dữ liệu nhị phân
    with open(input_path, 'r') as f:
        binary_data = f.read().strip().split()
    
    # Chuyển đổi từng byte thành ký tự
    message = ''
    for byte in binary_data:
        if byte == '11111111':  # Delimiter
            break
        message += chr(int(byte, 2))
    
    # Tạo tên file output
    output_path = os.path.splitext(input_path)[0] + '_text.txt'
    
    # Lưu kết quả
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(message)
        
    return output_path, len(message)

if __name__ == "__main__":
    try:
        print(f"Đang xử lý file: {INPUT_BINARY_PATH}")
        output_file, msg_len = convert_to_text()
        print(f"\nĐã chuyển đổi thành công!")
        print(f"Độ dài tin nhắn: {msg_len} ký tự")
        print(f"Kết quả được lưu tại: {output_file}")
    except Exception as e:
        print(f"Lỗi: {str(e)}")
