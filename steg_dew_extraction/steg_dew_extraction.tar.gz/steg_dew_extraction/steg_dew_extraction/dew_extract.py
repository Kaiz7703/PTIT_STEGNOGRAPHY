import cv2
import numpy as np
from scipy.fft import dct
import argparse
import os

class DEWExtractor:
    def __init__(self, block_size=8, n=2):
        self.block_size = block_size
        self.n = n

    def calculate_energy(self, dct_block, start_idx, end_idx):
        """Tính năng lượng trong vùng DCT"""
        return np.sum(np.square(dct_block[start_idx:end_idx]))

    def extract_message(self, input_video):
        print("Đang xử lý video...", end=' ')
        cap = cv2.VideoCapture(input_video)
        if not cap.isOpened():
            raise Exception("Không thể mở video")

        extracted_bits = []
        current_byte = ''
        frame_count = 0
        found_delimiter = False
        
        while cap.isOpened() and not found_delimiter:
            ret, frame = cap.read()
            if not ret:
                break

            # Chỉ xử lý I-frames (mỗi GOP)
            if frame_count % 12 == 0:
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                
                # Xử lý theo vùng lc
                for i in range(0, gray.shape[0] - self.block_size + 1, self.block_size * self.n):
                    for j in range(0, gray.shape[1] - self.block_size + 1, self.block_size * self.n):
                        block = gray[i:i+self.block_size, j:j+self.block_size]
                        dct_block = dct(dct(block.T, norm='ortho').T, norm='ortho')

                        # Tính năng lượng các vùng
                        EA = self.calculate_energy(dct_block, 0, 35)
                        EB = self.calculate_energy(dct_block, 35, 64)

                        # Xác định bit
                        bit = '0' if EA > EB else '1'
                        current_byte += bit

                        if len(current_byte) == 8:
                            if current_byte == '11111111':  # Delimiter
                                found_delimiter = True
                                break
                            extracted_bits.append(current_byte)
                            current_byte = ''

            frame_count += 1

        cap.release()

        # Lưu kết quả dưới dạng nhị phân
        output_file = input_video.rsplit('.', 1)[0] + '_extracted_binary.txt'
        with open(output_file, 'w') as f:
            f.write('\n'.join(extracted_bits))  # Mỗi byte trên một dòng

        print("OK!")
        return output_file

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Tách tin từ video MPEG sử dụng phương pháp DEW')
    parser.add_argument('video_path', help='Đường dẫn đến video cần tách tin')
    args = parser.parse_args()

    try:
        print("\n=== CHƯƠNG TRÌNH TÁCH TIN BẰNG PHƯƠNG PHÁP DEW ===\n")
        extractor = DEWExtractor()
        output_file = extractor.extract_message(args.video_path)
        print(f"\nĐã lưu dữ liệu nhị phân vào file: {output_file}")
        print("Sử dụng binary_to_text.py để chuyển đổi sang văn bản")

    except Exception as e:
        print(f"\nLỗi: {str(e)}")
