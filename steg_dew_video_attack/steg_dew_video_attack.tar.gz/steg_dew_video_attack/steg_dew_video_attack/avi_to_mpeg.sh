#!/bin/bash

# Đường dẫn file .avi bạn sẽ điền vào đây
input_avi="your_input_file.avi"

# Tạo tên file đầu ra .mpeg từ tên file đầu vào
output_mpeg="${input_avi%.*}.mpeg"

# Chạy chuyển đổi bằng ffmpeg
ffmpeg -i "$input_avi" -qscale:v 2 "$output_mpeg"