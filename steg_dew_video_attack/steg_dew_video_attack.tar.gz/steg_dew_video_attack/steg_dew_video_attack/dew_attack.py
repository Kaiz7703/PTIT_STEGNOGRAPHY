import cv2
import numpy as np
from scipy.fft import dct, idct
import argparse

class DEWAttacker:
    def __init__(self, block_size=8):
        self.block_size = block_size
        self.attack_methods = {
            'noise': self.add_noise_attack,
            'zero': self.zero_coefficients_attack,
            'shuffle': self.shuffle_coefficients_attack
        }

    def add_noise_attack(self, dct_block):
        noise = np.random.normal(0, 0.1, dct_block.shape)
        return dct_block + noise

    def zero_coefficients_attack(self, dct_block):
        mask = np.random.choice([0, 1], dct_block.shape, p=[0.3, 0.7])
        return dct_block * mask

    def shuffle_coefficients_attack(self, dct_block):
        flat = dct_block.flatten()
        np.random.shuffle(flat)
        return flat.reshape(dct_block.shape)

    def attack_video(self, input_video, attack_type='noise'):
        if attack_type not in self.attack_methods:
            raise ValueError("Phương pháp tấn công không hợp lệ")

        print(f"Đang tấn công video bằng phương pháp {attack_type}...", end=' ')
        cap = cv2.VideoCapture(input_video)
        if not cap.isOpened():
            raise Exception("Không thể mở video")

        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        fps = int(cap.get(cv2.CAP_PROP_FPS))
        output_path = input_video.rsplit('.', 1)[0] + f'_attacked_{attack_type}.avi'

        fourcc = cv2.VideoWriter_fourcc(*'MJPG')
        out = cv2.VideoWriter(output_path, fourcc, fps, (width, height), isColor=True)

        frame_count = 0
        attack_method = self.attack_methods[attack_type]

        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break

            if frame_count % 12 == 0:
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                attacked_gray = np.zeros_like(gray)

                for i in range(0, height - self.block_size + 1, self.block_size):
                    for j in range(0, width - self.block_size + 1, self.block_size):
                        block = gray[i:i+self.block_size, j:j+self.block_size]
                        dct_block = dct(dct(block.T, norm='ortho').T, norm='ortho')
                        attacked_block = attack_method(dct_block)
                        block = idct(idct(attacked_block.T, norm='ortho').T, norm='ortho')
                        block = np.clip(block, 0, 255)
                        attacked_gray[i:i+self.block_size, j:j+self.block_size] = block

                attacked_gray = attacked_gray.astype(np.uint8)
                frame = cv2.cvtColor(attacked_gray, cv2.COLOR_GRAY2BGR)

            out.write(frame)
            frame_count += 1

        cap.release()
        out.release()
        print("OK!")
        return output_path

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Tấn công video đã giấu tin bằng DEW')
    parser.add_argument('video_path', help='Đường dẫn đến video cần tấn công')
    parser.add_argument('--method', 
                        choices=['noise', 'zero', 'shuffle'],
                        default='noise',
                        help='Phương pháp tấn công')
    args = parser.parse_args()

    try:
        print("\n=== CHƯƠNG TRÌNH TẤN CÔNG STEGANOGRAPHY DEW ===\n")
        attacker = DEWAttacker()
        output_path = attacker.attack_video(args.video_path, args.method)
        print(f"\nĐã lưu video đã tấn công tại: {output_path}")
    except Exception as e:
        print(f"\nLỗi: {str(e)}")
