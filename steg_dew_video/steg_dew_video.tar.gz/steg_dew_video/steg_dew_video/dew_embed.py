import cv2
import numpy as np
from scipy.fft import dct, idct
import argparse
import os
import subprocess  # Thêm import này

class DEWEmbedder:
    def __init__(self, block_size=8, n=2, D=100, c_min=35):
        self.block_size = block_size
        self.n = n  # Kích thước vùng lc
        self.D = D  # Ngưỡng năng lượng
        self.c_min = c_min
        
    def calculate_energy(self, dct_block, start_idx, end_idx):
        """Tính năng lượng trong vùng DCT từ start_idx đến end_idx"""
        return np.sum(np.square(dct_block[start_idx:end_idx]))
    
    def find_c_index(self, dct_blocks):
        """Tìm chỉ số c tối ưu theo công thức trong lý thuyết"""
        max_c = self.block_size * self.block_size - 1
        c = self.c_min
        
        for g in range(self.c_min, max_c):
            EA = np.mean([self.calculate_energy(block, 0, g) for block in dct_blocks])
            EB = np.mean([self.calculate_energy(block, g, max_c) for block in dct_blocks])
            
            if EA > self.D and EB > self.D:
                c = g
                
        return max(self.c_min, c)

    def embed_message(self, input_video, message_file):
        # Kiểm tra file đầu vào
        if not os.path.exists(input_video):
            raise FileNotFoundError(f"Không tìm thấy file video: {input_video}")
        if not os.path.exists(message_file):
            raise FileNotFoundError(f"Không tìm thấy file tin nhắn nhị phân: {message_file}")
            
        print("Đang đọc tin nhắn nhị phân...", end=' ')
        # Đọc trực tiếp tin nhắn nhị phân
        with open(message_file, 'r') as f:
            binary_message = f.read().strip()
        print(f"OK! (Độ dài: {len(binary_message)} bits)")
        
        # Đếm số I-frames trước khi xử lý
        print("Đang đếm số I-frames...", end=' ')
        temp_cap = cv2.VideoCapture(input_video)
        i_frame_count = 0
        frame_idx = 0
        
        while temp_cap.isOpened():
            ret, _ = temp_cap.read()
            if not ret:
                break
            if frame_idx % 12 == 0:  # GOP size = 12
                i_frame_count += 1
            frame_idx += 1
            
        temp_cap.release()
        
        # Ghi số I-frames vào file
        info_path = "Prefix_video.txt"
        with open(info_path, 'w', encoding='utf-8') as f:
            f.write(f"Số I-frames: {i_frame_count}")
        print(f"OK! ({i_frame_count} frames)")
        
        print("Đang xử lý video...", end=' ')
        cap = cv2.VideoCapture(input_video)
        if not cap.isOpened():
            raise Exception("Không thể mở video")
            
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
        fps = int(cap.get(cv2.CAP_PROP_FPS))
        
        # Tạo video output với codec và bitrate phù hợp
        output_path = input_video.rsplit('.', 1)[0] + '_embedded.avi'
        fourcc = cv2.VideoWriter_fourcc(*'XVID')  # Thay MJPG bằng XVID để nén tốt hơn
        
        # Thiết lập parameters
        out = cv2.VideoWriter(
            output_path, 
            fourcc, 
            fps, 
            (width, height),
            isColor=True
        )
        
        if not out.isOpened():
            raise Exception("Không thể tạo file output video")

        bit_idx = 0
        frame_count = 0
        
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
                
            # Chỉ xử lý I-frames (mỗi GOP) và khi còn bit cần giấu
            if frame_count % 12 == 0 and bit_idx < len(binary_message):  
                gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
                
                # Xử lý theo vùng lc
                for i in range(0, height - self.block_size + 1, self.block_size * self.n):
                    for j in range(0, width - self.block_size + 1, self.block_size * self.n):
                        if bit_idx >= len(binary_message):
                            break
                            
                        # Tính c cho vùng lc hiện tại
                        block = gray[i:i+self.block_size, j:j+self.block_size]
                        dct_block = dct(dct(block.T, norm='ortho').T, norm='ortho')
                        
                        # Giấu bit dựa trên năng lượng
                        bit = int(binary_message[bit_idx])
                        if bit == 0:
                            dct_block[35:] = 0
                        else:
                            dct_block[:35] = 0
                            
                        block = idct(idct(dct_block.T, norm='ortho').T, norm='ortho')
                        gray[i:i+self.block_size, j:j+self.block_size] = block
                        bit_idx += 1
                
                frame = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)
            
            out.write(frame)
            frame_count += 1
            
        cap.release()
        out.release()
        
        # Sửa phần convert video
        print("\nChuyển đổi sang định dạng MPEG...")
        final_output = output_path.replace('.avi', '.mpeg')
        
        # Sửa lại tham số ffmpeg để giảm dung lượng
        ffmpeg_cmd = [
            'ffmpeg', '-i', output_path,
            '-c:v', 'mpeg1video',
            '-b:v', '1000k',  # Giảm bitrate xuống
            '-minrate', '500k',  # Thêm giới hạn bitrate tối thiểu
            '-maxrate', '1500k',  # Thêm giới hạn bitrate tối đa
            '-bufsize', '2000k',
            '-s', f'{width}x{height}',
            '-r', str(fps),
            '-q:v', '8',  # Tăng mức nén (2-31, càng cao càng nén nhiều)
            '-g', '12',
            '-bf', '0',
            '-flags', '-ilme-ildct',
            '-y',
            final_output
        ]

        try:
            print("Đang chạy lệnh ffmpeg...")
            result = subprocess.run(
                ffmpeg_cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                universal_newlines=True,
                check=True  # Raise exception if ffmpeg fails
            )
            
            if os.path.exists(final_output) and os.path.getsize(final_output) > 0:
                if os.path.exists(output_path):
                    os.remove(output_path)
                output_path = final_output
                print("Chuyển đổi thành công!")
            else:
                print("Lỗi: File output không hợp lệ")
                return False, output_path

        except subprocess.CalledProcessError as e:
            print("Lỗi khi chuyển đổi video:")
            print(e.stderr)
            return False, output_path
        except Exception as e:
            print(f"Lỗi không xác định: {str(e)}")
            return False, output_path
        
        print(f"\nĐã xử lý {frame_count} frames")
        if bit_idx >= len(binary_message):
            print("Giấu tin thành công!")
        else:
            print(f"Warning: Chỉ giấu được {bit_idx}/{len(binary_message)} bits")
        
        return True, output_path

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Giấu tin vào video MPEG sử dụng phương pháp DEW')
    parser.add_argument('video_path', help='Đường dẫn đến video cần giấu tin')
    parser.add_argument('message_file', help='Đường dẫn đến file chứa tin nhắn')
    args = parser.parse_args()
    
    try:
        print("\n=== CHƯƠNG TRÌNH GIẤU TIN BẰNG PHƯƠNG PHÁP DEW ===\n")
        embedder = DEWEmbedder()
        success, output_path = embedder.embed_message(args.video_path, args.message_file)
        if success:
            print(f"\nKết quả đã được lưu tại: {output_path}")
        
    except Exception as e:
        print(f"\nLỗi: {str(e)}")
