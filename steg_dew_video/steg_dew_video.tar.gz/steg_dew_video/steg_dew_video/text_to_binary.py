import os

INPUT_TEXT_PATH = ""  # PATH

def convert_to_binary(input_path=INPUT_TEXT_PATH):
    """Converting to binary"""
    if not os.path.exists(input_path):
        raise FileNotFoundError(f"Can't find file: {input_path}")
        
    with open(input_path, 'r', encoding='utf-8') as f:
        message = f.read().strip()
        
    binary_message = ''.join(format(ord(c), '08b') for c in message) + '11111111'
    
    output_path = os.path.splitext(input_path)[0] + '_binary.txt'
    
    with open(output_path, 'w') as f:
        f.write(binary_message)
        
    return output_path, len(message)

if __name__ == "__main__":
    try:
        print(f"Processing file: {INPUT_TEXT_PATH}")
        output_file, msg_len = convert_to_binary()
        print(f"\nSuccess!")
        print(f"Length: {msg_len} ký tự")
        print(f"Result saved at: {output_file}")
    except Exception as e:
        print(f"Error: {str(e)}")
